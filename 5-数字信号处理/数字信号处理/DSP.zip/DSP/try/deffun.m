function[O1,O2]=deffun(A,B)
O1=A+A+A;
O2=B+B+B;