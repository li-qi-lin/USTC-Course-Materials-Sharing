xn=[1 1 0 1];
syms w;

X1=1+exp(-1i*w)+exp(-1i*3*w);
subplot(3,1,1);
fplot(abs(X1));
title('DTFT');

k=0:3;
X2=1+exp(-1i*pi*0.5*k)+exp(-1i*pi*1.5*k);
subplot(3,1,2);
stem(k,abs(X2));
title('DFT');

X3=0.25*(X2(1)*(1-exp(-4i*w))/(1-exp(-1i*w))+X2(2)*(1-exp(-4i*w))/(1-exp(0.5*pi)*exp(-1i*w))+X2(3)*(1-exp(-4i*w))/(1-exp(0.5*2*pi)*exp(-1i*w))+X2(4)*(1-exp(-4i*w))/(1-exp(0.5*3*pi)*exp(-1i*w)));
subplot(3,1,3);
fplot(abs(X3));
title('重建');